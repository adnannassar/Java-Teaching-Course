package AdvancedKurs.PK_Klausuren.Klausur_02_2022.Aufgabe_1;

public class Angestellter {
    String name;
    double gehalt;

    public Angestellter(String name, double gehalt) {
        this.name = name;
        this.gehalt = gehalt;
    }
}
