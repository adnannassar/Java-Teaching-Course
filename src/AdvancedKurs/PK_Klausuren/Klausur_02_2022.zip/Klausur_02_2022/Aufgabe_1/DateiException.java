package AdvancedKurs.PK_Klausuren.Klausur_02_2022.Aufgabe_1;

public class DateiException extends Exception {
    public DateiException() {
    }

    public DateiException(String message) {
        super(message);
    }
}
